
var lat = null;
var lng = null;


function getLatLng(){
if(navigator.geolocation){
	navigator.geolocation.getCurrentPosition(function(position){
		lat = position.coords.latitude;
		lng = position.coords.longitude;
		var mapOptions = {
		center : new google.maps.LatLng(lat,lng),
		zoom:15,
		MapType : google.maps.MapTypeId.TERRAIN
	}
	new google.maps.Map(document.getElementById("maps"),mapOptions);
	});
}

}
