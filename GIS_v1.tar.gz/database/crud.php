<?php
class crud{
	
	function __construct(){
	mysql_connect("localhost","root","") or die(mysql_error());
	mysql_select_db("kecoa_v1");
	}
	function security($data){
		return htmlentities(htmlspecialchars(strip_tags($data)));
	}
	function saveData($longitude,$latitude){
		$sql = mysql_query("INSERT INTO `atribute`(`longitude`, `latitude`) VALUES ('$longitude','$latitude')") or die(mysql_error());
		return $this->checkBoolean($sql);
	}
	function checkBoolean($param){
		if($param){
			return true;
		}else{
			return false;
		}
	}
}
?>