$(function(){

$("#formRegister").hide();
$("#formLogin").show();
$("#activeLog").on("click",function(){
$("#formRegister").hide();
$("#formLogin").show();
});
$("#activeReg").on("click",function(){
$("#formRegister").show();
$("#formLogin").hide();

});

function checkValue(param){
if(param=="success"){
 		alert("success");
 	}else{
 		alert(param);
 	}
}
$("#btnRegister").on("click",function(){
	var $formReg = $("#formRegister").serialize();
 $.post("database/register.php",$formReg,function(data,success){
 	//checkValue(data);
 	window.location="front.php";
 });
});

$("#btnLogin").on("click",function(){
	var $formLog = $("#formLogin").serialize();
$.post("database/login.php",$formLog,function(data,success){
	//checkValue(data);
	window.location="index.php";
})

});
});