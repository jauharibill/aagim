<!DOCTYPE html>
<html>
<head>
	<title>Get location</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script type="text/javascript" src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
	<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js"></script>
	<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.js"></script>
	<script type="text/javascript" src="js/front.js"></script>
	<link rel="stylesheet" type="text/css" href="css/login.css">
	<!--<script type="text/javascript" src="js/googleMaps.js"></script>
	<script type="text/javascript" src="js/mobile.js"></script>
	<link rel="stylesheet" type="text/css" href="css/mobile.css">-->
</head>
<body>
<div id="wrapper">
<!-- <div class="frontTitle">AKUISISI DAN ANALISIS JALAN RUSAK BERBASIS GEOGRAPHY INFORMATION SYSTEM</div> -->
<div class="formGroup">
<form class="form" id="formRegister" method="post">
	<div><input type="text" class="inputText" name="username" placeholder="Username"></div>
	<div><input type="text" class="inputText" name="email" placeholder="Email"></div>
	<div><input type="password" class="inputText" name="password" class="password" placeholder="Password"></div>
	<div><input type="password" class="inputText" name="repassword" class="password" placeholder="Re Password"></div>
	<div><button type="button" class="btn" name="btnRegister" id="btnRegister">Register</button><button type="reset" class="btn">Reset</button></div>
	<div><button type="button" class="btn"id="activeLog">Login</button></div>
</form>
<form class="form" id="formLogin" method="post">
	<div><input type="username" class="inputText" name="username" placeholder="Username"></div>
	<div><input type="password" class="inputText" name="password" placeholder="password"></div>
	<div><button type="button" class="btn" id="btnLogin">Login</button></div>
	<div><button type="button" class="btn"id="activeReg">Register</button></div>
</form></div></div>
</body>
</html>